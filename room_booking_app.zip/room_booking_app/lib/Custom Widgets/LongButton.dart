import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

class LongButton extends StatefulWidget {
  final String text;
  final Function() onPressed;

  LongButton({required this.onPressed, required this.text});

  @override
  _LongButtonState createState() => _LongButtonState();
}

class _LongButtonState extends State<LongButton> {
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 350,
      height: 50,
      decoration: BoxDecoration(
        color: Color(0xFF2443ac),
        borderRadius: BorderRadius.circular(10),
      ),
      child: _isLoading
          ? Center(
              child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Loading...",
                  textScaleFactor: 1.25,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
                Gap(20),
                CircularProgressIndicator(
                  color: Colors.white,
                ),
              ],
            ))
          : TextButton(
              onPressed: () {
                setState(() {
                  _isLoading = true;
                });

                // Call the provided onPressed function
                widget.onPressed().then((_) {
                  setState(() {
                    _isLoading = false;
                  });
                });
              },
              child: Text(
                _isLoading ? 'Processing...' : widget.text,
                textScaleFactor: 1.25,
                style: TextStyle(
                  color: Color(0xFFFFFFFF),
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                ),
              ),
            ),
    );
  }
}
