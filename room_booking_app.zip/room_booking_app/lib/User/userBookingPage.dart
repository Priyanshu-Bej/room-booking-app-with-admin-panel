import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:room_booking_app/controllers/bookingController.dart';
import 'package:room_booking_app/models/bookingModel.dart';

class UserBookingsPage extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final BookingController bookingController = Get.put(BookingController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Bookings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FutureBuilder<void>(
          future: bookingController.fetchBookings(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: CircularProgressIndicator(),
              );
            } else if (snapshot.hasError) {
              return Center(
                child: Text('Error fetching bookings: ${snapshot.error}'),
              );
            } else {
              String? currentUserEmail = _auth.currentUser?.email;

              if (currentUserEmail != null) {
                List<BookingModel> userBookings = bookingController.bookings
                    .where((booking) => booking.userEmail == currentUserEmail)
                    .toList();

                return ListView.builder(
                  itemCount: userBookings.length,
                  itemBuilder: (context, index) {
                    BookingModel booking = userBookings[index];

                    return Card(
                      elevation: 3,
                      child: ListTile(
                        title: Text('Booking ${index + 1}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Check-in: ${booking.checkInDate}'),
                            Text('Check-out: ${booking.checkOutDate}'),
                            Text('Total Persons: ${booking.totalPersons}'),
                            Text(
                              'Rooms: ${booking.bookedRoomNumbers.join(', ')}',
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              } else {
                return Center(
                  child: Text('No Bookings'),
                );
              }
            }
          },
        ),
      ),
    );
  }
}
