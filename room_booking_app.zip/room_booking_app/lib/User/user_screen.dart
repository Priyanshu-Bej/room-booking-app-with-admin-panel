import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:room_booking_app/Login%20Screen/LoginScreen.dart';
import 'package:room_booking_app/Login%20Screen/authServices.dart';
import 'package:room_booking_app/User/RoomDetailsPage.dart';
import 'package:room_booking_app/User/bookRoomPage.dart';
import 'package:room_booking_app/User/userBookingPage.dart';
import 'package:room_booking_app/controllers/roomController.dart';
import 'package:room_booking_app/models/room_model.dart';

class UserScreen extends StatelessWidget {
  final RoomController roomController = Get.put(RoomController());
  AuthService authService = AuthService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Screen'),
        actions: [
          IconButton(
            onPressed: () {
              Fluttertoast.showToast(msg: "Refreshed");
              roomController.fetchRooms();
            },
            icon: Icon(Icons.refresh),
          ),
          IconButton(
              onPressed: () async {
                await authService.signOut();
                Get.off(LoginScreen());
                Fluttertoast.showToast(msg: 'Logged out successfully');
              },
              icon: Icon(
                Icons.logout,
              )),
        ],
      ),
      body: Obx(
        () => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 20),
                          child: SizedBox(
                            height: 80,
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () => Get.to(
                                BookRoomPage(),
                              ),
                              style: ElevatedButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: Colors.blue,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50),
                                ),
                              ),
                              child: Text(
                                "Book Room",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Gap(10),
                    Expanded(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 20),
                          child: SizedBox(
                            height: 80,
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () => Get.to(UserBookingsPage()),
                              style: ElevatedButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: Colors.green,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50),
                                ),
                              ),
                              child: Text(
                                "Your Bookings",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Divider(),
                Text(
                  "All Rooms",
                  style: GoogleFonts.poppins(
                    fontSize: 25,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: roomController.rooms.length > 0
                      ? ListView.builder(
                          itemCount: roomController.rooms.length,
                          itemBuilder: (context, index) {
                            final room = roomController.rooms[index];
                            return _buildRoomCard(room);
                          },
                        )
                      : Center(
                          child: Center(
                            child: Text(
                              'No rooms available',
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRoomCard(Room room) {
    return GestureDetector(
      onTap: () {
        _onRoomCardTap(room);
      },
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Card(
          elevation: 5,
          margin: EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
                child: Stack(
                  children: [
                    if (room.image != null)
                      Container(
                        height: 150,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: FileImage(File(room.image!.path)),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    Positioned(
                      top: 10,
                      right: 10,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: room.isBooked ? Colors.red : Colors.green,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          room.isBooked ? 'Booked' : 'Available',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      room.roomId,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text('Location: ${room.location}'),
                    SizedBox(height: 8),
                    Text('Price: ₹${room.price.toStringAsFixed(2)}'),
                    SizedBox(height: 8),
                    Text('Available Rooms: ${room.available_Rooms}'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onRoomCardTap(Room room) {
    Get.to(RoomDetailsPage(
      room: room,
    ));
  }
}
