import 'dart:math';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:room_booking_app/controllers/roomController.dart';
import 'package:room_booking_app/models/room_model.dart';

class BookRoomPage extends StatefulWidget {
  const BookRoomPage({Key? key}) : super(key: key);

  @override
  State<BookRoomPage> createState() => _BookRoomPageState();
}

class _BookRoomPageState extends State<BookRoomPage> {
  TextEditingController fromDateController = TextEditingController();
  TextEditingController toDateController = TextEditingController();
  TextEditingController numberOfPersonsController = TextEditingController();
  final RoomController roomController = Get.put(RoomController());

  DateTime fromDate = DateTime.now();
  DateTime toDate = DateTime.now().add(const Duration(days: 1));
  Set<int> selectedRoomIndices = {};

  Future<void> _selectDate(
      BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(DateTime.now().year + 1),
    );
    if (picked != null && picked != DateTime.now()) {
      controller.text = "${picked.day}/${picked.month}/${picked.year}";
      if (controller == fromDateController) {
        setState(() {
          fromDate = picked;
        });
      } else if (controller == toDateController) {
        setState(() {
          toDate = picked;
        });
      }
    }
  }

  int roomNeeded = 0;

  void calculateRequiredRooms(int numberOfPersons, int maxPersonsPerRoom) {
    if (numberOfPersons <= 0) {
      return;
    }

    roomNeeded = (numberOfPersons / maxPersonsPerRoom).ceil();
    print("Room Needed: $roomNeeded");
  }

  void bookSelectedRooms({
    required DateTime checkInDate,
    required DateTime checkOutDate,
    required int totalPersons,
    required List<int> selectedRoomIndices,
  }) async {
    try {
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userEmail = user.email ?? 'default@example.com';

        DocumentReference bookingRef =
            await FirebaseFirestore.instance.collection('bookings').add({
          'userEmail': userEmail,
          'checkInDate': checkInDate,
          'checkOutDate': checkOutDate,
          'totalPersons': totalPersons,
        });

        List<String> bookedRoomNumbers = [];

        for (int roomIndex in selectedRoomIndices) {
          Room room = roomController.rooms[roomIndex];

          await FirebaseFirestore.instance
              .collection('rooms')
              .doc(room.roomId)
              .update({
            'isBooked': true,
          });

          bookedRoomNumbers.add(room.roomId);
        }

        await bookingRef.update({
          'bookedRoomNumbers': bookedRoomNumbers,
        });

        _showToast('Rooms booked successfully!');
      } else {
        _showToast('User not logged in.');
      }
    } catch (e) {
      print('Error booking rooms: $e');

      _showToast('Error booking rooms: $e');
    }
  }

  void _showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor:
          message.contains('successfully') ? Colors.green : Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  @override
  void initState() {
    super.initState();
    numberOfPersonsController.addListener(() {
      setState(() {
        int number_of_persons =
            int.parse(numberOfPersonsController.text.trim());
        print("Number of Persons: $number_of_persons");
        calculateRequiredRooms(number_of_persons, 2);
      });
    });

    Future.delayed(Duration(milliseconds: 300), () {
      _selectRooms();
    });
  }

  void _selectRooms() {
    selectedRoomIndices.clear();
    for (int i = 0; i < min(roomController.rooms.length, roomNeeded); i++) {
      try {
        final roomIndex = i % roomController.rooms.length;
        final room = roomController.rooms[roomIndex];

        if (!room.isBooked) {
          selectedRoomIndices.add(roomIndex);
        }
      } catch (e) {
        print("Error adding available rooms to selection: $e");
      }
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        forceMaterialTransparency: true,
        title: const Text('Book Room'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () => _selectDate(context, fromDateController),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            const Text('Check-In Date'),
                            const Gap(5),
                            if (fromDate != null)
                              Text(
                                '${fromDate!.day}/${fromDate!.month}/${fromDate!.year}',
                                style: const TextStyle(fontSize: 16),
                              ),
                            const Gap(5),
                          ],
                        ),
                      ),
                    ),
                    const Gap(8),
                    ElevatedButton(
                      onPressed: () => _selectDate(context, toDateController),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            const Text('Check-Out Date'),
                            const Gap(5),
                            if (toDate != null)
                              Text(
                                '${toDate!.day}/${toDate!.month}/${toDate!.year}',
                                style: const TextStyle(fontSize: 16),
                              ),
                            const Gap(5),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const Gap(10),
                Text(
                  "Enter Persons",
                  style: GoogleFonts.poppins(
                    fontSize: 17,
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                TextField(
                  controller: numberOfPersonsController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: "Enter Number of Persons",
                    contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                    hintStyle: GoogleFonts.poppins(fontSize: 13),
                    border: const OutlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFFFFFFFF)),
                    ),
                    prefixIcon: const Icon(Icons.person),
                  ),
                ),
                const Gap(5),
                const Text(
                  '* For one room only 2 persons can be allotted.',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.blue,
                  ),
                ),
                const Text(
                  '* Select all the room to Book',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.green,
                  ),
                ),
                const Gap(10),
                ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: min(roomController.rooms.length, roomNeeded),
                  itemBuilder: (context, index) {
                    try {
                      final roomIndex = index % roomController.rooms.length;
                      final room = roomController.rooms[roomIndex];
                      return _availableRooms(room, roomIndex);
                    } catch (e) {
                      if (e is RangeError) {
                        print("Error building room list: $e");
                        return const Text("Error: Not enough rooms available");
                      } else {
                        print("Unexpected error building room list: $e");
                        return Container();
                      }
                    }
                  },
                ),
                const Gap(30),
                Center(
                  child: SizedBox(
                    height: 55,
                    width: 340,
                    child: ElevatedButton(
                      onPressed: () async {
                        User? user = FirebaseAuth.instance.currentUser;
                        String userEmail = user?.email ?? 'user@gmail.com';
                        print(userEmail);
                        bookSelectedRooms(
                          checkInDate: fromDate,
                          checkOutDate: toDate,
                          totalPersons:
                              int.parse(numberOfPersonsController.text),
                          selectedRoomIndices: selectedRoomIndices.toList(),
                        );
                      },
                      child: Text("Book"),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _availableRooms(Room room, int roomIndex) {
    bool isSelected = selectedRoomIndices.contains(roomIndex);

    if (room.isBooked) {
      return Container();
    }

    return GestureDetector(
      onTap: () {
        setState(() {
          if (isSelected) {
            selectedRoomIndices.remove(roomIndex);
          } else {
            selectedRoomIndices.add(roomIndex);
          }
        });
      },
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Card(
          elevation: 5,
          margin: const EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Room No :${room.roomId}",
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text('Price: ₹${room.price.toStringAsFixed(2)}'),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Colors.blue
                            : room.isBooked
                                ? Colors.red
                                : Colors.green,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        isSelected
                            ? 'Selected'
                            : room.isBooked
                                ? 'Booked'
                                : 'Available',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// import 'dart:io';
// import 'dart:math';

// import 'package:flutter/material.dart';
// import 'package:gap/gap.dart';
// import 'package:get/get.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:room_booking_app/colors.dart';
// import 'package:room_booking_app/controllers/user_controller.dart';
// import 'package:room_booking_app/models/room_model.dart';

// class BookRoomPage extends StatefulWidget {
//   const BookRoomPage({
//     Key? key,
//   }) : super(key: key);

//   @override
//   State<BookRoomPage> createState() => _BookRoomPageState();
// }

// class _BookRoomPageState extends State<BookRoomPage> {
//   TextEditingController fromDateController = TextEditingController();
//   TextEditingController toDateController = TextEditingController();
//   TextEditingController numberOfPersonsController = TextEditingController();
//   final RoomController roomController = Get.put(RoomController());

//   DateTime? fromDate;
//   DateTime? toDate;
//   double totalAmount = 0.0;

//   Future<void> _selectDate(
//       BuildContext context, TextEditingController controller) async {
//     final DateTime? picked = await showDatePicker(
//       context: context,
//       initialDate: DateTime.now(),
//       firstDate: DateTime.now(),
//       lastDate: DateTime(DateTime.now().year + 1),
//     );
//     if (picked != null && picked != DateTime.now()) {
//       controller.text = "${picked.day}/${picked.month}/${picked.year}";
//       if (controller == fromDateController) {
//         setState(() {
//           fromDate = picked;
//         });
//       } else if (controller == toDateController) {
//         setState(() {
//           toDate = picked;
//         });
//       }
//     }
//   }

//   int roomNeeded = 0;
//   void calculateRequiredRooms(int numberOfPersons, int maxPersonsPerRoom) {
//     if (numberOfPersons <= 0) {
//       return;
//     }

//     roomNeeded = (numberOfPersons / maxPersonsPerRoom).ceil();
//     print(roomNeeded);
//   }

//   // void _bookNow() async {
//   //   if (fromDate!.isAfter(toDate!) || fromDate!.isBefore(DateTime.now())) {
//   //     _showToast('Invalid date range. Please select valid dates.');
//   //     return;
//   //   }

//   //   if (fromDateController.text.isEmpty || toDateController.text.isEmpty) {
//   //     _showToast('Please select both start and end dates.');
//   //     return;
//   //   }
//   //   if (numberOfPersonsController.text.isEmpty) {
//   //     _showToast('Please enter the number of persons.');
//   //     return;
//   //   }
//   //   try {
//   //     // Perform booking logic and update Firestore collections
//   //     DocumentReference bookingRef =
//   //         await FirebaseFirestore.instance.collection('bookings').add({
//   //       'userId': 'user123', // Replace with actual user ID
//   //       'fromDate': fromDate,
//   //       'toDate': toDate,
//   //       'numberOfPersons': numberOfPersonsController.text.trim(),
//   //     });

//   //     for (int i = 0; i < roomNeeded; i++) {
//   //       await bookingRef.collection('rooms').add({
//   //         // 'roomId': widget.room!.roomId,
//   //         // 'price': widget.room!.price,
//   //         // Add other room details as needed
//   //       });
//   //     }

//   //     // Update available rooms in the 'rooms' collection
//   //     await FirebaseFirestore.instance
//   //         .collection('rooms')
//   //         .doc(widget.room!.roomId)
//   //         .update({
//   //       'availableRooms': widget.room!.available_Rooms - roomNeeded,
//   //     });

//   //     // Show booking status
//   //     _showToast('Your room has been booked successfully!');
//   //     setState(() {
//   //       roomController.fetchRooms();
//   //     });
//   //   } catch (e) {
//   //     print('Error booking room: $e');
//   //     _showToast('An error occurred while processing your booking.');
//   //   }
//   // }

//   void bookSelectedRooms({
//     required DateTime checkInDate,
//     required DateTime checkOutDate,
//     required int totalPersons,
//     required String userEmail,
//     required List<int> selectedRoomIndices,
//   }) async {
//     try {
//       // Create a booking in the "bookings" collection
//       DocumentReference bookingRef =
//           await FirebaseFirestore.instance.collection('bookings').add({
//         'userEmail': userEmail,
//         'checkInDate': checkInDate,
//         'checkOutDate': checkOutDate,
//         'totalPersons': totalPersons,
//       });

//       // Update the "rooms" collection for selected rooms
//       for (int roomIndex in selectedRoomIndices) {
//         Room room = roomController.rooms[roomIndex];

//         // Update isBooked to true for the selected room
//         await FirebaseFirestore.instance
//             .collection('rooms')
//             .doc(room.roomId)
//             .update({
//           'isBooked': true,
//         });

//         // Add a reference to the booked room in the booking document
//         await bookingRef.collection('rooms').add({
//           'roomId': room.roomId,
//           'price': room.price,
//           // Add other room details as needed
//         });
//       }

//       // Perform additional actions if needed

//       print('Rooms booked successfully!');
//     } catch (e) {
//       print('Error booking rooms: $e');
//       // Handle the error as needed
//     }
//   }

//   void _showToast(String message) {
//     Fluttertoast.showToast(
//       msg: message,
//       toastLength: Toast.LENGTH_SHORT,
//       gravity: ToastGravity.BOTTOM,
//       backgroundColor: Colors.green,
//       textColor: Colors.white,
//       fontSize: 16.0,
//     );
//   }

//   @override
//   void initState() {
//     super.initState();
//     numberOfPersonsController.addListener(() {
//       setState(() {
//         calculateRequiredRooms(int.parse(numberOfPersonsController.text), 2);
//       });
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Book Room'),
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () {
//             Get.back();
//           },
//         ),
//       ),
//       body: SafeArea(
//         child: SingleChildScrollView(
//           child: Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     ElevatedButton(
//                       onPressed: () => _selectDate(context, fromDateController),
//                       child: Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Column(
//                           children: [
//                             Text('Check-In Date'),
//                             Gap(5),
//                             if (fromDate != null)
//                               Text(
//                                 '${fromDate!.day}/${fromDate!.month}/${fromDate!.year}',
//                                 style: TextStyle(fontSize: 16),
//                               ),
//                             Gap(5),
//                           ],
//                         ),
//                       ),
//                     ),
//                     Gap(8),
//                     ElevatedButton(
//                       onPressed: () => _selectDate(context, toDateController),
//                       child: Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Column(
//                           children: [
//                             Text('Check-Out Date'),
//                             Gap(5),
//                             if (toDate != null)
//                               Text(
//                                 '${toDate!.day}/${toDate!.month}/${toDate!.year}',
//                                 style: TextStyle(fontSize: 16),
//                               ),
//                             Gap(5),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 Gap(10),
//                 Text(
//                   "Enter Persons",
//                   style: GoogleFonts.poppins(
//                     fontSize: 17,
//                   ),
//                 ),
//                 const SizedBox(
//                   height: 5,
//                 ),
//                 TextField(
//                   controller: numberOfPersonsController,
//                   keyboardType: TextInputType.number,
//                   decoration: InputDecoration(
//                     hintText: "Enter Number of Persons",
//                     contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
//                     hintStyle: GoogleFonts.poppins(fontSize: 13),
//                     border: OutlineInputBorder(
//                       borderSide: BorderSide(color: Color(0xFFFFFFFF)),
//                     ),
//                     prefixIcon: Icon(Icons.person),
//                   ),
//                 ),
//                 Gap(5),
//                 Text(
//                   '* For one room only 2 persons can be allotted.',
//                   style: TextStyle(
//                     fontSize: 13,
//                     color: Colors.blue,
//                   ),
//                 ),
//                 Gap(10),
//                 // ListView.builder(
//                 //   physics: NeverScrollableScrollPhysics(),
//                 //   shrinkWrap: true,
//                 //   itemCount: roomNeeded,
//                 //   itemBuilder: (context, index) {
//                 //     final room = roomController.rooms[index];
//                 //     return _availableRooms(room);
//                 //   },
//                 // ),
//                 ListView.builder(
//                   physics: NeverScrollableScrollPhysics(),
//                   shrinkWrap: true,
//                   itemCount: min(roomController.rooms.length, roomNeeded),
//                   itemBuilder: (context, index) {
//                     try {
//                       final roomIndex = index % roomController.rooms.length;
//                       final room = roomController.rooms[roomIndex];
//                       return _availableRooms(room);
//                     } catch (e) {
//                       if (e is RangeError) {
//                         print("Error building room list: $e");
//                         return Text("Error: Not enough rooms available");
//                       } else {
//                         print("Unexpected error building room list: $e");
//                         return Container();
//                       }
//                     }
//                   },
//                 ),
//                 // Text(
//                 //   'Total Amount: ₹${totalAmount.toStringAsFixed(2)}',
//                 //   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 // ),
//                 Gap(30),
//                 Center(
//                   child: SizedBox(
//                       height: 55,
//                       width: 340,
//                       child: ElevatedButton(
//                         onPressed: () {
//                           // bookSelectedRooms(
//                           //   checkInDate: fromDate!,
//                           //   checkOutDate: toDate!,
//                           //   totalPersons:
//                           //       int.parse(numberOfPersonsController.text),
//                           //   userEmail:
//                           //       'user@example.com', // Replace with the actual user email
//                           //   selectedRoomIndices: selectedRoomIndices.toList(),
//                           // );
//                         },
//                         child: Text("Book"),
//                       )),
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _availableRooms(Room room) {
//     return room.isBooked == false
//         ? GestureDetector(
//             onTap: () {
//               print(room.roomId);
//             },
//             child: Padding(
//               padding: const EdgeInsets.all(5.0),
//               child: Card(
//                 elevation: 5,
//                 margin: EdgeInsets.only(bottom: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(15.0),
//                 ),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(16.0),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text(
//                                 "Room No :${room.roomId}",
//                                 style: TextStyle(
//                                   fontSize: 18,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                               // SizedBox(height: 8),
//                               // Text('Location: ${room.location}'),
//                               SizedBox(height: 8),
//                               Text('Price: ₹${room.price.toStringAsFixed(2)}'),
//                               // SizedBox(height: 8),
//                               // Text('Available Rooms: ${room.available_Rooms}'),
//                             ],
//                           ),
//                           Container(
//                             padding: EdgeInsets.symmetric(
//                                 horizontal: 8, vertical: 4),
//                             decoration: BoxDecoration(
//                               color: room.isBooked ? Colors.red : Colors.green,
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//                             child: Text(
//                               room.isBooked ? 'Booked' : 'Available',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           )
//         : Container();
//   }
// }
