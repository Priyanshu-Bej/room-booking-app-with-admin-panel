import 'dart:io';

class Room {
  String roomId;
  double price;
  String description;
  String name;
  String location;

  int available_Rooms;
  bool isBooked;
  File? image;

  Room({
    required this.roomId,
    required this.price,
    required this.name,
    required this.description,
    required this.location,
    required this.available_Rooms,
    this.isBooked = false,
    this.image,
  });

  factory Room.fromJson(Map<String, dynamic> json) {
    return Room(
      roomId: json['roomId'],
      name: json['name'],
      price: json['price'],
      description: json['description'],
      location: json['location'],
      available_Rooms: json['availableRooms'],
      isBooked: json['isBooked'] ?? false,
      image: json['image'] != null ? File(json['image']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'roomId': roomId,
      'price': price,
      'name': name,
      'description': description,
      'location': location,
      'availableRooms': available_Rooms,
      'isBooked': isBooked,
      'image': image?.path,
    };
  }
}
