import 'package:cloud_firestore/cloud_firestore.dart';

class BookingModel {
  final String userEmail;
  final DateTime checkInDate;
  final DateTime checkOutDate;
  final int totalPersons;
  final List<String> bookedRoomNumbers;

  BookingModel({
    required this.userEmail,
    required this.checkInDate,
    required this.checkOutDate,
    required this.totalPersons,
    required this.bookedRoomNumbers,
  });

  factory BookingModel.fromMap(Map<String, dynamic> map) {
    return BookingModel(
      userEmail: map['userEmail'] ?? '',
      checkInDate: (map['checkInDate'] as Timestamp).toDate(),
      checkOutDate: (map['checkOutDate'] as Timestamp).toDate(),
      totalPersons: map['totalPersons'] ?? 0,
      bookedRoomNumbers: List<String>.from(map['bookedRoomNumbers'] ?? []),
    );
  }
}
