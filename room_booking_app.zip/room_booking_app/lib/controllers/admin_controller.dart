import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:room_booking_app/models/room_model.dart';

class AdminController extends GetxController {
  RxList<Room> rooms = <Room>[].obs;

  final CollectionReference roomsCollection =
      FirebaseFirestore.instance.collection('rooms');

  Future<void> addRoom(Room room) async {
    try {
      await roomsCollection.doc(room.roomId).set(room.toJson());
      rooms.add(room);
    } catch (e) {
      print('Error adding room: $e');
    }
  }

  Future<void> viewRooms() async {
    try {
      QuerySnapshot querySnapshot = await roomsCollection.get();
      rooms.clear();
      querySnapshot.docs.forEach((doc) {
        rooms.add(Room.fromJson(doc.data() as Map<String, dynamic>));
      });
    } catch (e) {
      print('Error fetching rooms: $e');
    }
  }
}
