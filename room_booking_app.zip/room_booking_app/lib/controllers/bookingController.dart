import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:room_booking_app/models/bookingModel.dart';

class BookingController extends GetxController {
  RxList<BookingModel> bookings = <BookingModel>[].obs;

  Future<void> fetchBookings() async {
    try {
      QuerySnapshot querySnapshot =
          await FirebaseFirestore.instance.collection('bookings').get();

      bookings.assignAll(querySnapshot.docs
          .map(
              (doc) => BookingModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList());
    } catch (e) {
      print('Error fetching bookings: $e');
    }
  }
}
