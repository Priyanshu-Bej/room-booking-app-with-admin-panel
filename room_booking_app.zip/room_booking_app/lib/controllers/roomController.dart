import 'dart:io';

import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:room_booking_app/models/room_model.dart';

class RoomController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final rooms = <Room>[].obs;
  final Rx<List<Room>> roomsStream = Rx<List<Room>>([]);

  @override
  void onInit() {
    super.onInit();
    fetchRooms();
  }

  final selectedRooms = <Room>{}.obs;
  void fetchRooms() async {
    try {
      final querySnapshot =
          await FirebaseFirestore.instance.collection('rooms').get();
      rooms.value = querySnapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return Room(
          roomId: data['roomId'],
          name: data['name'] ?? '',
          price: (data['price'] ?? 0.0).toDouble(),
          description: data['description'] ?? '',
          location: data['location'] ?? '',
          available_Rooms: (data['availableRooms'] ?? 0).toInt(),
          isBooked: data['isBooked'] ?? false,
          image: data['image'] != null ? File(data['image']) : null,
        );
      }).toList();
      roomsStream.value = rooms.toList();
    } catch (e) {
      print('Error fetching rooms: $e');
    }
  }

  Future<void> fetch_Rooms() async {
    try {
      final querySnapshot =
          await FirebaseFirestore.instance.collection('rooms').get();
      rooms.value = querySnapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return Room(
          roomId: data['roomId'],
          name: data['name'] ?? '',
          price: (data['price'] ?? 0.0).toDouble(),
          description: data['description'] ?? '',
          location: data['location'] ?? '',
          available_Rooms: (data['availableRooms'] ?? 0).toInt(),
          isBooked: data['isBooked'] ?? false,
          image: data['image'] != null ? File(data['image']) : null,
        );
      }).toList();
      roomsStream.value = rooms.toList();
    } catch (e) {
      print('Error fetching rooms: $e');
    }
  }
  void toggleSelected(Room room) {
    if (selectedRooms.contains(room)) {
      selectedRooms.remove(room);
    } else {
      selectedRooms.add(room);
    }
  }
  Future<void> deleteSelectedRooms() async {
    for (final room in selectedRooms) {
      try {
        await _firestore.collection('rooms').doc(room.roomId).delete();
        print('Deleted room: ${room.name}');
      } catch (e) {
        print('Error deleting room: ${room.name}, $e');
      }
    }
    selectedRooms.clear();
  }
}
