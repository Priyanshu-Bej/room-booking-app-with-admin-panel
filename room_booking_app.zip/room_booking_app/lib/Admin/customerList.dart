import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:room_booking_app/Admin/adminList.dart';

class UserList extends StatelessWidget {
  final AdminListController adminListController =
      Get.put(AdminListController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User List'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Obx(
          () => adminListController.adminList.isEmpty
              ? Center(
                  child: Text('No user data available.'),
                )
              : ListView.builder(
                  itemCount: adminListController.adminList.length,
                  itemBuilder: (context, index) {
                    final adminData = adminListController.adminList[index];
                    final serialNumber = index + 1;
                    return _buildAdminCard(serialNumber, adminData);
                  },
                ),
        ),
      ),
    );
  }

  Widget _buildAdminCard(int serialNumber, Map<String, dynamic>? adminData) {
    if (adminData == null) {
      return Container(); // You can customize this part based on your UI needs
    }

    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: CircleAvatar(
          child: Text(
            serialNumber.toString(),
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.purple,
        ),
        title: Text(
          adminData['name'] ?? 'Name not available',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              adminData['email'] ?? 'Email not available',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              adminData['phone'] ?? 'Phone not available',
              style: TextStyle(fontSize: 15, color: Colors.blue),
            ),
          ],
        ),
        trailing: Icon(
          Icons.admin_panel_settings,
          color: Colors.blue,
        ),
      ),
    );
  }
}
