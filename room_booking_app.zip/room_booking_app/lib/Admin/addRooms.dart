import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:room_booking_app/controllers/admin_controller.dart';
import 'package:room_booking_app/models/room_model.dart';

class AddRoomPage extends StatefulWidget {
  @override
  State<AddRoomPage> createState() => _AddRoomPageState();
}

class _AddRoomPageState extends State<AddRoomPage> {
  final AdminController adminController = Get.put(AdminController());

  TextEditingController nameController = TextEditingController();

  TextEditingController roomNoController = TextEditingController();

  TextEditingController priceController = TextEditingController();

  TextEditingController descriptionController = TextEditingController();

  TextEditingController locationController = TextEditingController();

  TextEditingController availableRooms = TextEditingController();

  File? selectedImage;

  void _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      selectedImage = File(pickedFile.path);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        forceMaterialTransparency: true,
        title: Text('Add Room'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Gap(10),
              GestureDetector(
                onTap: () {
                  _pickImage();
                },
                child: Container(
                  height: 200,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(15.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Center(
                    child: selectedImage != null
                        ? Container(
                            height: 190,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: FileImage(selectedImage!),
                                fit: BoxFit.fitHeight,
                              ),
                            ),
                          )
                        : Text(
                            'Tap to Select Image',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                            ),
                          ),
                  ),
                ),
              ),
              Gap(20),
              Text(
                "Name",
                style: GoogleFonts.poppins(
                  fontSize: 17,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  hintText: "Enter Name",
                  contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                  hintStyle: GoogleFonts.poppins(fontSize: 13),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFFFFF)),
                  ),
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              Gap(20),
              Text(
                "Room No",
                style: GoogleFonts.poppins(
                  fontSize: 17,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              TextField(
                controller: roomNoController,
                decoration: InputDecoration(
                  hintText: "Enter Room No",
                  contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                  hintStyle: GoogleFonts.poppins(fontSize: 13),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFFFFF)),
                  ),
                  prefixIcon: Icon(Icons.numbers),
                ),
              ),
              Gap(20),
              Text(
                "Price",
                style: GoogleFonts.poppins(
                  fontSize: 17,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              TextField(
                controller: priceController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: "Enter Price",
                  contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                  hintStyle: GoogleFonts.poppins(fontSize: 13),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFFFFF)),
                  ),
                  prefixIcon: Icon(Icons.currency_rupee_sharp),
                ),
              ),
              Gap(20),
              Text(
                "Description",
                style: GoogleFonts.poppins(
                  fontSize: 17,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  hintText: "Enter Description",
                  contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                  hintStyle: GoogleFonts.poppins(fontSize: 13),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFFFFF)),
                  ),
                  prefixIcon: Icon(Icons.description_outlined),
                ),
              ),
              Gap(20),
              Text(
                "Location",
                style: GoogleFonts.poppins(
                  fontSize: 17,
                ),
              ),
              const SizedBox(
                height: 5,
              ),
              TextField(
                controller: locationController,
                decoration: InputDecoration(
                  hintText: "Enter Location",
                  contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                  hintStyle: GoogleFonts.poppins(fontSize: 13),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFFFFF)),
                  ),
                  prefixIcon: Icon(Icons.location_on_outlined),
                ),
              ),
              Gap(20),

              // TextField(
              //   controller: availableRooms,
              //   keyboardType: TextInputType.number,
              //   decoration: InputDecoration(
              //     hintText: "Enter Available Rooms",
              //     contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
              //     hintStyle: GoogleFonts.poppins(fontSize: 13),
              //     border: OutlineInputBorder(
              //       borderSide: BorderSide(color: Color(0xFFFFFFFF)),
              //     ),
              //     prefixIcon: Icon(Icons.people_outline),
              //   ),
              // ),

              Center(
                child: SizedBox(
                  width: 340,
                  height: 55,
                  child: ElevatedButton(
                    onPressed: () {
                      _addRoom();
                    },
                    child: Text('Add Room'),
                  ),
                ),
              ),
              Gap(20),
            ],
          ),
        ),
      ),
    );
  }

  void _addRoom() {
    String name = nameController.text.trim();
    String roomNo = roomNoController.text.trim();
    double price = double.tryParse(priceController.text.trim()) ?? 0.0;
    String description = descriptionController.text.trim();
    String location = locationController.text.trim();
    int available_Rooms = int.tryParse(availableRooms.text.trim()) ?? 1;

    if (name.isNotEmpty &&
        roomNo.isNotEmpty &&
        price > 0 &&
        description.isNotEmpty &&
        location.isNotEmpty &&
        available_Rooms > 0) {
      Room newRoom = Room(
        roomId: roomNo,
        name: name,
        price: price,
        description: description,
        location: location,
        available_Rooms: available_Rooms,
        image: selectedImage,
      );

      adminController.addRoom(newRoom);

      nameController.clear();
      roomNoController.clear();
      priceController.clear();
      descriptionController.clear();
      locationController.clear();
      availableRooms.clear();
      selectedImage = null;
      Fluttertoast.showToast(msg: "Room Added");

      Get.back();
    } else {
      Fluttertoast.showToast(msg: "Please fill in all fields with valid data.");
    }
  }
}
