import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:room_booking_app/controllers/bookingController.dart';
import 'package:room_booking_app/models/bookingModel.dart';

class BookingListPage extends StatelessWidget {
  final BookingController bookingController = Get.put(BookingController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking List'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FutureBuilder(
          future: bookingController.fetchBookings(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else {
              return Obx(
                () => bookingController.bookings.isEmpty
                    ? Center(
                        child: Text('No bookings available.'),
                      )
                    : ListView.builder(
                        itemCount: bookingController.bookings.length,
                        itemBuilder: (context, index) {
                          final booking = bookingController.bookings[index];
                          final serialNumber = index + 1;
                          return _buildBookingCard(serialNumber, booking);
                        },
                      ),
              );
            }
          },
        ),
      ),
    );
  }

  Widget _buildBookingCard(int serialNumber, BookingModel booking) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: CircleAvatar(
          child: Text(
            serialNumber.toString(),
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.blue,
        ),
        title: Text(
          'User: ${booking.userEmail}',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Check-In: ${booking.checkInDate}'),
            Text('Check-Out: ${booking.checkOutDate}'),
            Text('Total Persons: ${booking.totalPersons}'),
            Text('Rooms: ${booking.bookedRoomNumbers.join(', ')}'),
          ],
        ),
      ),
    );
  }
}
