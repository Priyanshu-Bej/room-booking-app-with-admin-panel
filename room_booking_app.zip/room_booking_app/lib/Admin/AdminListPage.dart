import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:room_booking_app/Admin/adminList.dart';

class AdminListPage extends StatelessWidget {
  final AdminListController adminListController =
      Get.put(AdminListController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin List'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Obx(
          () => adminListController.adminList.isEmpty
              ? Center(
                  child: Text('No admin data available.'),
                )
              : ListView.builder(
                  itemCount: adminListController.adminList.length,
                  itemBuilder: (context, index) {
                    final adminData = adminListController.adminList[index];
                    final serialNumber = index + 1;
                    return _buildAdminCard(serialNumber, adminData);
                  },
                ),
        ),
      ),
    );
  }

  Widget _buildAdminCard(int serialNumber, Map<String, dynamic> adminData) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: CircleAvatar(
          child: Text(
            serialNumber.toString(),
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.purple,
        ),
        title: Text(
          adminData['name'],
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              adminData['email'],
              style: TextStyle(fontSize: 16),
            ),
            Text(
              adminData['phone'],
              style: TextStyle(fontSize: 15, color: Colors.blue),
            ),
          ],
        ),
        trailing: Icon(
          Icons.admin_panel_settings,
          color: Colors.blue,
        ),
      ),
    );
  }
}
