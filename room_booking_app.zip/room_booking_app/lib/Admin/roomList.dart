import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:room_booking_app/controllers/roomController.dart';
import 'package:room_booking_app/models/room_model.dart';

class RoomListPage extends StatelessWidget {
  final RoomController roomController = Get.put(RoomController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Room List'),
        actions: [
          IconButton(
            onPressed: () {
              if (roomController.selectedRooms.isNotEmpty) {
                roomController.deleteSelectedRooms();
                roomController.fetchRooms();
              }
            },
            icon: Icon(Icons.delete),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FutureBuilder(
          future: roomController.fetch_Rooms(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error loading rooms'));
            } else {
              return Obx(() {
                return ListView.builder(
                  itemCount: roomController.rooms.length,
                  itemBuilder: (context, index) {
                    final room = roomController.rooms[index];
                    return _buildRoomCard(room);
                  },
                );
              });
            }
          },
        ),
      ),
    );
  }

  Widget _buildRoomCard(Room room) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Room No: ${room.roomId}",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              "Name: ${room.name}",
            ),
          ],
        ),
        subtitle: Text(
          'Rs.${room.price.toStringAsFixed(2)}\nLocation: ${room.location}',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
