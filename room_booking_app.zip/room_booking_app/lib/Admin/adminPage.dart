import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:room_booking_app/Admin/addRooms.dart';
import 'package:room_booking_app/Admin/adminList.dart';
import 'package:room_booking_app/Admin/bookingListPage.dart';
import 'package:room_booking_app/Admin/roomList.dart';
import 'package:room_booking_app/Login%20Screen/LoginScreen.dart';
import 'package:room_booking_app/Login%20Screen/authServices.dart';
import 'package:room_booking_app/Admin/AdminListPage.dart';
import 'package:room_booking_app/controllers/admin_controller.dart';
import 'package:room_booking_app/controllers/bookingController.dart';

class AdminPage extends StatelessWidget {
  final AdminController adminController = Get.put(AdminController());
  final BookingController bookingController = Get.put(BookingController());

  final AuthService authService = AuthService();
  final AdminListController adminListController =
      Get.put(AdminListController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('Admin Panel'),
        actions: [
          IconButton(
            onPressed: () async {
              await authService.signOut();
              Get.off(LoginScreen());
              Fluttertoast.showToast(msg: 'Logged out successfully');
            },
            icon: Icon(Icons.logout),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            _buildMenuItem(
              'Add Room',
              Icons.add,
              Colors.blue,
              () => Get.to(() => AddRoomPage()),
            ),
            _buildMenuItem(
              'View Bookings',
              Icons.calendar_today,
              Colors.orange,
              () {
                bookingController.fetchBookings();
                Get.to(BookingListPage());
              },
            ),
            _buildMenuItem(
              'Room List',
              Icons.bar_chart,
              Colors.green,
              () {
                Get.to(RoomListPage());
              },
            ),
            _buildMenuItem(
              'Admin List',
              Icons.security,
              Colors.purple,
              () {
                adminListController.fetchAdminData();
                Get.to(AdminListPage());
              },
            ),
            _buildMenuItem(
              'Customer List',
              Icons.security,
              Colors.teal,
              () {
                adminListController.fetchCustomerData();
                Get.to(AdminListPage());
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(
    String title,
    IconData icon,
    Color color,
    VoidCallback onPressed,
  ) {
    return GestureDetector(
      onTap: onPressed,
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(100),
        ),
        color: color,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 40,
              color: Colors.white,
            ),
            SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
