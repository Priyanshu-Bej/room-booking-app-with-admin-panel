import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminListController extends GetxController {
  RxList<Map<String, dynamic>> adminList = <Map<String, dynamic>>[].obs;

  Future<void> fetchAdminData() async {
    try {
      QuerySnapshot querySnapshot =
          await FirebaseFirestore.instance.collection('users').get();

      adminList.assignAll(querySnapshot.docs
          .where((doc) => doc['role'] == 'admin')
          .map((doc) => doc.data() as Map<String, dynamic>)
          .toList());
    } catch (e) {
      print('Error fetching admin data: $e');
    }
  }

  Future<void> fetchCustomerData() async {
    try {
      QuerySnapshot querySnapshot =
          await FirebaseFirestore.instance.collection('users').get();

      adminList.assignAll(querySnapshot.docs
          .where((doc) => doc['role'] == 'user')
          .map((doc) => doc.data() as Map<String, dynamic>)
          .toList());
    } catch (e) {
      print('Error fetching admin data: $e');
    }
  }
}
