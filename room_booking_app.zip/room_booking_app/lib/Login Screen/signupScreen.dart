import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:room_booking_app/Custom%20Widgets/LongButton.dart';
import 'package:room_booking_app/Login%20Screen/LoginScreen.dart';
import 'package:room_booking_app/Login%20Screen/authServices.dart';
import 'package:room_booking_app/colors.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var NameController = TextEditingController();
  var phoneController = TextEditingController();
  var confirmController = TextEditingController();
  bool isObscure = true;
  final AuthService authService = AuthService();
  String role = 'user';
  final _formKey = GlobalKey<FormState>();

  var isDark = false;

  String _errorMessage = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        forceMaterialTransparency: true,
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Icon(
            Icons.arrow_back_ios,
            size: 20,
            color: Colors.black,
          ),
        ),
        title: Text(
          "Sign Up",
          style: GoogleFonts.poppins(
            fontSize: 25,
            letterSpacing: 1,
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: Container(
              height: MediaQuery.of(context).size.height / 1.1,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Form(
                  key: _formKey,
                  child: Padding(
                    padding: const EdgeInsets.all(18.0),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Gap(30),
                          Text(
                            "Name",
                            style: GoogleFonts.poppins(
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          TextFormField(
                            controller: NameController,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Name';
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              hintText: "Enter Name",
                              contentPadding:
                                  const EdgeInsets.fromLTRB(20, 20, 20, 20),
                              hintStyle: GoogleFonts.poppins(
                                fontSize: 13,
                              ),
                              border: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xFFFFFFFF))),
                              prefixIcon: const Icon(Icons.person),
                            ),
                          ),
                          Gap(10),
                          Text(
                            "Phone Number",
                            style: GoogleFonts.poppins(
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          TextFormField(
                            keyboardType: TextInputType.phone,
                            controller: phoneController,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Phone Number';
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              hintText: "Enter Phone Number",
                              contentPadding:
                                  const EdgeInsets.fromLTRB(20, 20, 20, 20),
                              hintStyle: GoogleFonts.poppins(
                                fontSize: 13,
                              ),
                              border: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xFFFFFFFF))),
                              prefixIcon: const Icon(Icons.phone),
                            ),
                          ),
                          Gap(10),
                          Text(
                            "Email",
                            style: GoogleFonts.poppins(
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          TextFormField(
                            controller: emailController,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter Email';
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              hintText: "Enter Email Address",
                              contentPadding:
                                  const EdgeInsets.fromLTRB(20, 20, 20, 20),
                              hintStyle: GoogleFonts.poppins(
                                fontSize: 13,
                              ),
                              border: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xFFFFFFFF))),
                              prefixIcon: const Icon(Icons.mail_outline),
                            ),
                          ),
                          Gap(10),
                          Text(
                            "Password",
                            style: GoogleFonts.poppins(
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          TextFormField(
                            controller: passwordController,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter password';
                              }
                              return null;
                            },
                            obscureText: isObscure,
                            decoration: InputDecoration(
                              hintText: "Enter Password",
                              contentPadding:
                                  const EdgeInsets.fromLTRB(20, 20, 20, 20),
                              hintStyle: GoogleFonts.poppins(
                                fontSize: 13,
                              ),
                              border: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Color(0xFFFFFFFF)),
                              ),
                              prefixIcon: const Icon(Icons.lock_outline),
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    isObscure = !isObscure;
                                  });
                                },
                                child: Icon(
                                  isObscure
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ),
                          Gap(30),
                          LongButton(
                              onPressed: () async {
                                var result = await authService
                                    .registerWithEmailAndPassword(
                                        emailController.text.trim(),
                                        passwordController.text.trim(),
                                        NameController.text.trim(),
                                        role,
                                        phoneController.text.trim());

                                if (result == null) {
                                  Fluttertoast.showToast(
                                      msg: 'Registration Successful');
                                  Get.off(LoginScreen());
                                } else {
                                  Fluttertoast.showToast(
                                      msg: result.toString().toLowerCase());
                                }
                              },
                              text: "Sign Up"),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
