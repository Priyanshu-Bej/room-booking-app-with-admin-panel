import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<String?> registerWithEmailAndPassword(
    String email,
    String password,
    String name,
    String role,
    String phone,
  ) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);

      await _addUserRole(email, name, userCredential.user!.uid, role, phone);

      return null;
    } on FirebaseAuthException catch (e) {
      return e.code;
    } catch (e) {
      print("Error: $e");
      return 'Something went wrong : $e';
    }
  }

  Future<void> _addUserRole(String email, String name, String userId,
      String role, String phone) async {
    await FirebaseFirestore.instance.collection('users').doc(userId).set({
      'email': email,
      'name': name,
      'role': role,
      'uid': userId,
      'phone': phone,
    });
  }

  Future<String?> signInWithEmailAndPassword(
      String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return null;
    } on FirebaseAuthException catch (e) {
      return e.code;
    } catch (e) {
      print("Error: $e");
      return 'Something went wrong : $e';
    }
  }

  // Sign out
  Future<void> signOut() async {
    await _auth.signOut();
  }
}
