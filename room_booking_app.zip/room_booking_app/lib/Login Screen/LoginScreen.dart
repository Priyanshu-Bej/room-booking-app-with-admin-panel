import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:room_booking_app/Admin/adminPage.dart';
import 'package:room_booking_app/Custom%20Widgets/LongButton.dart';
import 'package:room_booking_app/Login%20Screen/authServices.dart';
import 'package:room_booking_app/Login%20Screen/signupScreen.dart';
import 'package:room_booking_app/User/user_screen.dart';
import 'package:room_booking_app/colors.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  final AuthService authService = AuthService();
  String role = 'user';
  Future<void> _resetPassword(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      Fluttertoast.showToast(
          msg: 'Password reset email sent. Check your inbox.');
    } catch (e) {
      print('Error sending password reset email: $e');
      Fluttertoast.showToast(
          msg: 'Failed to send password reset email. Please try again.');
    }
  }

  String? dropdownValue;
  bool isObscure = true;
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (Navigator.of(context).canPop()) {
          SystemNavigator.pop();
        } else {
          SystemNavigator.pop();
        }
        return true;
      },
      child: Scaffold(
        // backgroundColor: Tprimary,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      height: 150,
                    ),
                    Center(
                      child: Text(
                        "Log In",
                        style: GoogleFonts.poppins(
                          fontSize: 40,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    Gap(10),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(10, 0, 0, 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Email",
                            style: GoogleFonts.poppins(
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          TextFormField(
                            controller: emailController,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter userid';
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              hintText: "Enter Email Address",
                              contentPadding:
                                  const EdgeInsets.fromLTRB(20, 20, 20, 20),
                              hintStyle: GoogleFonts.poppins(
                                fontSize: 13,
                              ),
                              border: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xFFFFFFFF))),
                              prefixIcon: const Icon(Icons.mail_outline),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Text(
                            "Password",
                            style: GoogleFonts.poppins(
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          TextFormField(
                            controller: passwordController,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter password';
                              }
                              return null;
                            },
                            obscureText: isObscure,
                            decoration: InputDecoration(
                              hintText: "Enter Password",
                              contentPadding:
                                  const EdgeInsets.fromLTRB(20, 20, 20, 20),
                              hintStyle: GoogleFonts.poppins(
                                fontSize: 13,
                              ),
                              border: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Color(0xFFFFFFFF)),
                              ),
                              prefixIcon: const Icon(Icons.lock_outline),
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    isObscure = !isObscure;
                                  });
                                },
                                child: Icon(
                                  isObscure
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () {
                                if (emailController.text.trim().isNotEmpty) {
                                  _resetPassword(emailController.text.trim());
                                } else {
                                  Fluttertoast.showToast(
                                      msg: 'Please enter your email address.');
                                }
                              },
                              child: Text(
                                'Forgot Password?',
                                style: GoogleFonts.poppins(
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                          Gap(20),
                          LongButton(
                            onPressed: () async {
                              var email = emailController.text.trim();
                              var password = passwordController.text.trim();

                              if (email.isEmpty || password.isEmpty) {
                                // Show error toast
                                Fluttertoast.showToast(
                                    msg: 'Please fill in the data');
                                return;
                              }

                              try {
                                FirebaseAuth auth = FirebaseAuth.instance;
                                UserCredential userCredential =
                                    await auth.signInWithEmailAndPassword(
                                  email: email,
                                  password: password,
                                );

                                if (userCredential.user != null) {
                                  final DocumentSnapshot snap =
                                      await FirebaseFirestore.instance
                                          .collection('users')
                                          .doc(userCredential.user!.uid)
                                          .get();

                                  if (snap.exists) {
                                    Map<String, dynamic>? userData =
                                        snap.data() as Map<String, dynamic>?;

                                    if (userData != null &&
                                        userData.containsKey('role')) {
                                      String role = userData['role'].toString();
                                      print("User's role: $role");

                                      if (role == 'user') {
                                        print("User");
                                        Get.off(UserScreen());
                                      } else if (role == 'admin') {
                                        print("Admin");
                                        Get.off(AdminPage());
                                      }
                                    } else {
                                      print(
                                          "Role field not found in user document");
                                    }
                                  } else {
                                    print("User document not found");
                                  }
                                }
                              } on FirebaseAuthException catch (e) {
                                Fluttertoast.showToast(
                                    msg: e.code.toString().toLowerCase());
                              } catch (e) {
                                print("Error: $e");
                                Fluttertoast.showToast(
                                    msg: 'Something went wrong : $e');
                              }
                            },
                            text: "Login",
                          ),
                          Gap(7),
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                    margin: const EdgeInsets.only(
                                        left: 10.0, right: 15.0),
                                    child: Divider(
                                      color: Color(0xFFD7D9E1),
                                      height: 50,
                                    )),
                              ),
                              Expanded(
                                child: Container(
                                    margin: const EdgeInsets.only(
                                        left: 10.0, right: 15.0),
                                    child: Divider(
                                      color: Color(0xFFD7D9E1),
                                      height: 50,
                                    )),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Gap(10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("Don't have an account?",
                                  style: GoogleFonts.poppins(
                                    fontSize: 15,
                                  )),
                              TextButton(
                                  child: Text(
                                    "Sign Up!",
                                    style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  onPressed: () {
                                    Get.to(SignUp());
                                  }),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
