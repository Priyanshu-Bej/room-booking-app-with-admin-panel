import 'package:flutter/material.dart';

const Tprimary = Color(0xFF2443ac);
const Tsecondary = Color(0xFF4F4F4F);
const TsubTextColor = Color(0xFFA9A3A3);
const TfieldColor = Color(0xFFFFFFFF);
final TborderColor = Color(0xFFD7D9E1);
final Ttextcolor = Color(0xFF2C2929);
final progressColor = Color(0xffD0A507);
final backgroundColor = Color(0xFFF5F5F5);
final TLightgrey = Color(0xFFEEEEEE);
final TshadowColor = Color(0xffDDDDDD);
//SKU colors Imports

const Color primary = Color(0xfff2f9fe);
const Color secondary = Color(0xFFdbe4f3);
const Color black = Color(0xFF000000);
const Color white = Color(0xFFFFFFFF);
const Color grey = Colors.grey;
const Color red = Color(0xFFec5766);
const Color green = Color(0xFF43aa8b);
const Color blue = Color(0xFF28c2ff);
const Color buttoncolor = Color(0xff3e4784);
const Color mainFontColor = Color(0xff565c95);
const Color arrowbgColor = Color(0xffe4e9f7);
